const User = require("../models/User");


// Register User

const register = async (req, res) => {
    try {

        const { name, email, password } = req.body;

        // check
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).json({
                message: "Email Already Exists"
            });
        }

        //new user
        const user = await User.create({
            name,
            email,
            password,
        });

        res.status(201).json({
            message: "User Registered Successfully",
            user,
        });

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};


// login user

const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(404).json({
                message: "User Not Found"
            });
        }

        if (user.password !== password) {
            return res.status(400).json({
                message: "Invalid Password"
            });
        }

        res.status(200).json({
            message: "Login Successfully",
            user,
        });

    } catch (error) {
        console.log("Login Error:", error);

        res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    register,
    login,
};
