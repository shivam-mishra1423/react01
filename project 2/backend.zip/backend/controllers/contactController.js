const Contact = require("../models/Contact");


// add contact

const add = async (req, res) => {
    try {

        const { name, email, phone } = req.body;

        const contact = await Contact.create({
            name,
            email,
            phone,
        });

        res.status(201).json({
            message: "contact added",
            contact,
        });

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};

//get all
const getAll = async (req, res) => {
    try {

        const contacts = await Contact.find();

        res.status(200).json(contacts);

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};




//update
const edit = async (req, res) => {
    try {

        const { name, email, phone } = req.body;

        const contact = await Contact.findByIdAndUpdate(
            req.params.id,
            {
                name,
                email,
                phone,
            },
            { new: true }
        );

        if (!contact) {
            return res.status(404).json({
                message: "Contact Not Found",
            });
        }

        res.status(200).json({
            message: "contact update",
            contact,
        });

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};


// delete
const remove = async (req, res) => {
    try {

        const contact = await Contact.findByIdAndDelete(req.params.id);

        if (!contact) {
            return res.status(404).json({
                message: "Contact Not Found",
            });
        }

        res.status(200).json({
            message: "Contact Deleted Successfully",
        });

    } catch (error) {

        res.status(500).json({
            message: error.message,
        });

    }
};




module.exports = {
    add,
    getAll,
    edit,
    remove,
};