const express = require("express");
const dotenv = require("dotenv");

const cors = require("cors");

const connectDB = require("./config/db");

const authRoute = require('./routes/authRoute');
const contactRoutes = require("./routes/ContactRoutes");

dotenv.config();

const  app= express();

connectDB();

//middleware
app.use(cors());
app.use(express.json());

//routes
app.use("/api/auth", authRoute);
app.use("/api/contacts", contactRoutes);

app.get('/',(req,res)=>{
    res.end("testing server");
})

app.listen(3005);
console.log("server running")
