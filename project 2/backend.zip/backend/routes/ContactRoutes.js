const express= require("express")

const {add,getAll,edit,remove} = require("../controllers/contactController")

const router = express.Router();

//add contact
router.post("/",add);

//get all
router.get("/",getAll);

//ipdate
router.put("/:id", edit);


//for delete route
router.delete("/:id", remove);

module.exports = router;